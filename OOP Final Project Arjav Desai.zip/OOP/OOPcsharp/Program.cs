﻿using OOPcsharp.Encapsulation;
using OOPcsharp.Inheritance;
using OOPcsharp.Polymorphism;
using System;
using System.Collections.Generic;

namespace OOP
{
    class Program
    {
        static void Main(string[] args)
        {
            // Encapsulation
            #region Encapsulation

            Console.WriteLine("---------------- Encapsulation ----------------");

            Console.WriteLine(Environment.NewLine);

            Console.WriteLine("Enter First Name");
            var firstName = Console.ReadLine();

            Console.WriteLine("Enter Last Name");
            var LastName = Console.ReadLine();

            Console.WriteLine("Enter Total Number Of Experience in Numbers");
            var experience = Console.ReadLine();

            Console.WriteLine("Enter Current Company");
            var currentCompany = Console.ReadLine();

            Console.WriteLine("Enter Prefered Programming Language to work with");
            var programmingLanguage = Console.ReadLine();

            SoftwareEngineer softwareEngineer = new SoftwareEngineer(firstName, LastName, Convert.ToInt32(experience), currentCompany, programmingLanguage);
            softwareEngineer.BuildProject();

            PressToContinue();

            Console.WriteLine("---------------- Encapsulation ----------------");

            Console.WriteLine("Enter driver's First Name");
            var driverFirstName = Console.ReadLine();

            Console.WriteLine("Enter driver's Last Name");
            var driverLastName = Console.ReadLine();

            Console.WriteLine("Enter Total Number Of Experience in Numbers");
            var driverExperience = Console.ReadLine();

            Console.WriteLine("Enter Prefered Car");
            var favCar = Console.ReadLine();

            CarEngineer carEngineer = new CarEngineer(driverFirstName, driverLastName, Convert.ToInt32(driverExperience), favCar);
            carEngineer.BuildProject();

            PressToContinue();
            #endregion


            // Inheritance
            #region Inheritance

            Console.WriteLine("---------------- Inheritance ----------------");

            Console.WriteLine(Environment.NewLine);

            Console.WriteLine("Enter Developer's First Name");
            var devFirstName = Console.ReadLine();

            Console.WriteLine("Enter Developer's Last Name");
            var devLastName = Console.ReadLine();

            Console.WriteLine("Enter Programming language developer prefer most");
            var devProficincy = Console.ReadLine();

            FrontEndDeveloper frontEndDeveloper = new FrontEndDeveloper(devFirstName, devLastName, devProficincy);
            frontEndDeveloper.Position();
            frontEndDeveloper.Experience();

            Console.WriteLine("Enter Developer's Experience in numbers");
            var devExp = Console.ReadLine();

            Console.WriteLine("Enter Developer's city");
            var devCity = Console.ReadLine();

            Console.WriteLine("Enter Developer's country");
            var devCountry = Console.ReadLine();

            BackEndDeveloper backEndDeveloper = new BackEndDeveloper(firstName, LastName, Convert.ToInt32(devExp), devCity, devCountry);
            backEndDeveloper.Position();
            backEndDeveloper.Experience();
            backEndDeveloper.Team();

            PressToContinue();
            #endregion


            // Polymorphism
            #region Polymorphism

            Console.WriteLine("---------------- Polymorphism ----------------");

            Console.WriteLine(Environment.NewLine);

            List<string> computerLanguages = new List<string>();

            for (int i = 0; i < 4; i++)
            {
                switch (i)
                {
                    case 0:
                        Console.WriteLine($"Enter your {i + 1}st most prefered programming language");
                        break;

                    case 1:
                        Console.WriteLine($"Enter your {i + 1}nd most prefered programming language");
                        break;

                    case 2:
                        Console.WriteLine($"Enter your {i + 1}rd most prefered programming language");
                        break;

                    case 3:
                        Console.WriteLine($"Enter your {i + 1}th most prefered programming language");
                        break;

                    default:
                        Console.WriteLine($"Enter your {i + 1}th most prefered programming language");
                        break;
                }

                computerLanguages.Add(Console.ReadLine());
            }

            if (computerLanguages.Count > 0)
            {
                WebDeveloper webDeveloper = new WebDeveloper(computerLanguages[0]);
                webDeveloper.Code();
                webDeveloper.Code(computerLanguages[1]);

                List<Developer> developers = new List<Developer>() { new WebDeveloper(computerLanguages[2]), new AppDeveloper(computerLanguages[3]) };
                foreach (var item in developers)
                {
                    item.Code();
                }
            }
            else
                Console.WriteLine("Invalid Inputs");

            PressToContinue("Press any key to exit");

            #endregion

        }

        /// <summary>
        /// Method to contine the process
        /// </summary>
        /// <param name="message">Message to print</param>
        static void PressToContinue(string message = null)
        {
            if (!string.IsNullOrWhiteSpace(message))
                Console.WriteLine(message);
            else
                Console.WriteLine("Press any key to continue");

            Console.ReadKey();

            Console.WriteLine(Environment.NewLine);
        }
    }
}
