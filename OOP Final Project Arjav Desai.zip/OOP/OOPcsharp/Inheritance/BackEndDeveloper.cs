﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OOPcsharp.Inheritance
{
    /*
     * Example of a Class that inherits from abstract class and interface
     * 
     * */

    public class BackEndDeveloper : TechProfessional, ITeamMember
    {
        private int _yearsExperience;

        private string _local;
        private string _area;

        /// <summary>
        /// Interface implementation of property
        /// </summary>
        public string TeamName
        {
            get
            {
                return string.Format("{0} {1}", this._local, this._area);
            }
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="firstName"></param>
        /// <param name="lastName"></param>
        /// <param name="yearsExperience"></param>
        /// <param name="local"></param>
        /// <param name="area"></param>
        public BackEndDeveloper(string firstName, string lastName, int yearsExperience, string local, string area) : base(firstName, lastName)
        {
            this._yearsExperience = yearsExperience;
            this._local = local;
            this._area = area;
        }

        /// <summary>
        /// Implementation of abstract method
        /// for ref: https://www.w3schools.com/cs/cs_abstract.php
        /// </summary>
        public override void Position()
        {
            Console.WriteLine(string.Format("Hey my name is {0}. I am a BackEnd Developer!", this.FullName));
        }

        /// <summary>
        /// Implementation of virtual method, example of Dynamic / Runtime Polymorphism
        /// </summary>
        public override void Experience()
        {
            Console.WriteLine(string.Format("Hey my name is {0}. I am a BackEnd Developer with {1} year(s) of experience!", this.FullName, this._yearsExperience));
        }

        /// <summary>
        /// Interface implementation
        /// </summary>
        public void Team()
        {
            Console.WriteLine(string.Format("Hey my name is {0}. I am a BackEnd Developer from {1} team.", this.FullName, this.TeamName));
        }
    }
}
